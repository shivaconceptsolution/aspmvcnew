﻿using Microsoft.AspNetCore.Mvc;

namespace Basicwebapplication.Models
{
    public class SIModel 
    {
        public float p { get; set; }
        public float r { get;set; }
        public float t { get; set; } 

    }
}
