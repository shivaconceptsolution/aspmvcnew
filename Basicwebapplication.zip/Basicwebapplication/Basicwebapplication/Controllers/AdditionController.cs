﻿using Microsoft.AspNetCore.Mvc;

namespace Basicwebapplication.Controllers
{
    public class AdditionController : Controller
    {
        public IActionResult Index()
        {
            int a = 100, b = 200, c;
            c = a + b;
            ViewBag.key = c;
            return View();
        }
    }
}
