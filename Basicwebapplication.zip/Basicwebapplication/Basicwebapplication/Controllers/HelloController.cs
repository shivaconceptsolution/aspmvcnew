﻿using Microsoft.AspNetCore.Mvc;

namespace Basicwebapplication.Controllers
{
    public class HelloController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
