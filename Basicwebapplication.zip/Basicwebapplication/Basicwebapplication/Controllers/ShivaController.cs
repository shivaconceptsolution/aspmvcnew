﻿using Microsoft.AspNetCore.Mvc;

namespace Basicwebapplication.Controllers
{
    public class ShivaController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
