﻿using Microsoft.AspNetCore.Mvc;

namespace Basicwebapplication.Controllers
{
    public class SidhiController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
