﻿using Microsoft.AspNetCore.Mvc;

namespace Basicwebapplication.Controllers
{
    public class SIController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Index(IFormCollection obj)
        {
            float p = float.Parse(obj["txtp"]);
            float r = float.Parse(obj["txtr"]);
            float t = float.Parse(obj["txtt"]);
            float si;
            si = (p * r * t) / 100;
            ViewBag.key = "Result is "+ si;
            return View();
        }
    }
}
