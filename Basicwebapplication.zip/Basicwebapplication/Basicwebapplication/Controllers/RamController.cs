﻿using Microsoft.AspNetCore.Mvc;

namespace Basicwebapplication.Controllers
{
    public class RamController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
