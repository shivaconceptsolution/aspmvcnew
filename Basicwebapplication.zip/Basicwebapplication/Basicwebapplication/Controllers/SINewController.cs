﻿using Microsoft.AspNetCore.Mvc;
using Basicwebapplication.Models;
namespace Basicwebapplication.Controllers
{
    public class SINewController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Index(SIModel obj)
        {
            float si = (obj.p * obj.r * obj.t) / 100;
            ViewBag.data = si;
            return View();
        }
    }
}
